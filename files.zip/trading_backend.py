from flask import Flask, jsonify, request
from flask_cors import CORS
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import requests
import json

app = Flask(__name__)
CORS(app)

# Simulated AI Model for predictions
class ForexPredictor:
    def __init__(self):
        self.model_confidence = 0.75
    
    def predict_movement(self, historical_data):
        """Predict next price movement using simple ML logic"""
        if len(historical_data) < 2:
            return {"direction": "neutral", "confidence": 0.5, "predicted_change": 0}
        
        recent_trend = (historical_data[-1] - historical_data[-2]) / historical_data[-2]
        volatility = np.std(historical_data[-20:]) if len(historical_data) >= 20 else np.std(historical_data)
        
        # Simple prediction logic
        if recent_trend > 0.001:
            direction = "up"
            confidence = min(0.8, 0.5 + abs(recent_trend) * 100)
        elif recent_trend < -0.001:
            direction = "down"
            confidence = min(0.8, 0.5 + abs(recent_trend) * 100)
        else:
            direction = "neutral"
            confidence = 0.5
        
        predicted_change = recent_trend * 100  # percentage change
        
        return {
            "direction": direction,
            "confidence": confidence,
            "predicted_change": predicted_change,
            "volatility": volatility
        }

# Risk Management Calculator
class RiskManager:
    @staticmethod
    def calculate_position_size(account_balance, risk_percent, entry_price, stop_loss):
        """Calculate safe position size based on risk management rules"""
        risk_amount = account_balance * (risk_percent / 100)
        price_diff = abs(entry_price - stop_loss)
        
        if price_diff == 0:
            return 0
        
        position_size = risk_amount / price_diff
        return round(position_size, 2)
    
    @staticmethod
    def calculate_reward_risk_ratio(entry_price, stop_loss, take_profit):
        """Calculate risk/reward ratio"""
        risk = abs(entry_price - stop_loss)
        reward = abs(take_profit - entry_price)
        
        if risk == 0:
            return 0
        
        return round(reward / risk, 2)

predictor = ForexPredictor()

# Mock Forex Data - Replace with real API (Alpha Vantage, IQ Option, etc.)
forex_data = {
    "EURUSD": [1.0800, 1.0805, 1.0810, 1.0815, 1.0820, 1.0818, 1.0825, 1.0830],
    "GBPUSD": [1.2700, 1.2705, 1.2710, 1.2715, 1.2720, 1.2718, 1.2725, 1.2730],
    "USDJPY": [150.50, 150.55, 150.60, 150.65, 150.70, 150.68, 150.75, 150.80],
}

@app.route('/api/currencies', methods=['GET'])
def get_currencies():
    """Get list of available currency pairs"""
    return jsonify({
        "currencies": list(forex_data.keys()),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/price/<currency>', methods=['GET'])
def get_price(currency):
    """Get current price for a currency pair"""
    if currency not in forex_data:
        return jsonify({"error": "Currency not found"}), 404
    
    prices = forex_data[currency]
    current_price = prices[-1]
    
    return jsonify({
        "currency": currency,
        "current_price": current_price,
        "24h_high": max(prices),
        "24h_low": min(prices),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/predict/<currency>', methods=['GET'])
def get_prediction(currency):
    """Get AI prediction for currency movement"""
    if currency not in forex_data:
        return jsonify({"error": "Currency not found"}), 404
    
    prices = forex_data[currency]
    prediction = predictor.predict_movement(prices)
    
    return jsonify({
        "currency": currency,
        "current_price": prices[-1],
        "prediction": prediction,
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/risk-management', methods=['POST'])
def calculate_risk():
    """Calculate risk management parameters"""
    data = request.json
    
    try:
        account_balance = data.get('account_balance', 10000)
        risk_percent = data.get('risk_percent', 2)
        entry_price = data.get('entry_price')
        stop_loss = data.get('stop_loss')
        take_profit = data.get('take_profit')
        
        position_size = RiskManager.calculate_position_size(
            account_balance, risk_percent, entry_price, stop_loss
        )
        
        rr_ratio = RiskManager.calculate_reward_risk_ratio(
            entry_price, stop_loss, take_profit
        )
        
        return jsonify({
            "position_size": position_size,
            "risk_reward_ratio": rr_ratio,
            "max_loss": account_balance * (risk_percent / 100),
            "potential_profit": position_size * (take_profit - entry_price)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/recommendations', methods=['GET'])
def get_recommendations():
    """Get AI-powered trading recommendations"""
    recommendations = []
    
    for currency in forex_data.keys():
        prices = forex_data[currency]
        prediction = predictor.predict_movement(prices)
        
        if prediction['confidence'] > 0.65:
            recommendation = {
                "currency": currency,
                "action": "BUY" if prediction['direction'] == "up" else "SELL",
                "confidence": round(prediction['confidence'] * 100, 2),
                "current_price": prices[-1],
                "predicted_change": f"{prediction['predicted_change']:.2f}%"
            }
            recommendations.append(recommendation)
    
    return jsonify({
        "recommendations": recommendations,
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "service": "Trading Platform Backend"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
