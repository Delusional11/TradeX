import React, { useState, useEffect } from 'react';
import './App.css';

const API_URL = 'http://localhost:5000/api';

function App() {
  const [currencies, setCurrencies] = useState([]);
  const [selectedCurrency, setSelectedCurrency] = useState(null);
  const [prices, setPrices] = useState({});
  const [predictions, setPredictions] = useState({});
  const [recommendations, setRecommendations] = useState([]);
  const [riskParams, setRiskParams] = useState({
    account_balance: 10000,
    risk_percent: 2,
    entry_price: 1.0800,
    stop_loss: 1.0790,
    take_profit: 1.0820
  });
  const [riskResults, setRiskResults] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch initial data
  useEffect(() => {
    fetchCurrencies();
    fetchRecommendations();
    const interval = setInterval(() => {
      fetchRecommendations();
    }, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  // Fetch currencies and their prices
  const fetchCurrencies = async () => {
    try {
      const res = await fetch(`${API_URL}/currencies`);
      const data = await res.json();
      setCurrencies(data.currencies);
      
      // Fetch price for each currency
      data.currencies.forEach(currency => {
        fetchPrice(currency);
        fetchPrediction(currency);
      });
    } catch (error) {
      console.error('Error fetching currencies:', error);
    }
  };

  const fetchPrice = async (currency) => {
    try {
      const res = await fetch(`${API_URL}/price/${currency}`);
      const data = await res.json();
      setPrices(prev => ({
        ...prev,
        [currency]: data
      }));
    } catch (error) {
      console.error(`Error fetching price for ${currency}:`, error);
    }
  };

  const fetchPrediction = async (currency) => {
    try {
      const res = await fetch(`${API_URL}/predict/${currency}`);
      const data = await res.json();
      setPredictions(prev => ({
        ...prev,
        [currency]: data.prediction
      }));
    } catch (error) {
      console.error(`Error fetching prediction for ${currency}:`, error);
    }
  };

  const fetchRecommendations = async () => {
    try {
      const res = await fetch(`${API_URL}/recommendations`);
      const data = await res.json();
      setRecommendations(data.recommendations);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      setLoading(false);
    }
  };

  const calculateRisk = async () => {
    try {
      const res = await fetch(`${API_URL}/risk-management`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(riskParams)
      });
      const data = await res.json();
      setRiskResults(data);
    } catch (error) {
      console.error('Error calculating risk:', error);
    }
  };

  const handleRiskParamChange = (field, value) => {
    setRiskParams(prev => ({
      ...prev,
      [field]: parseFloat(value)
    }));
  };

  return (
    <div className="app">
      <header className="header">
        <h1>🤖 AI Forex Trading Platform</h1>
        <p>Real-time predictions & Risk Management</p>
      </header>

      <div className="container">
        {/* Trading Board - Currency Prices */}
        <section className="trading-board">
          <h2>📊 Live Trading Board</h2>
          <div className="currency-grid">
            {currencies.map(currency => (
              <div 
                key={currency} 
                className={`currency-card ${selectedCurrency === currency ? 'selected' : ''}`}
                onClick={() => setSelectedCurrency(currency)}
              >
                <div className="currency-name">{currency}</div>
                <div className="currency-price">
                  {prices[currency]?.current_price?.toFixed(4) || 'Loading...'}
                </div>
                <div className="currency-stats">
                  <span>H: {prices[currency]?.['24h_high']?.toFixed(4)}</span>
                  <span>L: {prices[currency]?.['24h_low']?.toFixed(4)}</span>
                </div>
                {predictions[currency] && (
                  <div className={`prediction ${predictions[currency].direction}`}>
                    {predictions[currency].direction.toUpperCase()}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* AI Recommendations */}
        <section className="recommendations">
          <h2>🎯 AI Trading Recommendations</h2>
          {loading ? (
            <p>Loading recommendations...</p>
          ) : recommendations.length > 0 ? (
            <div className="recommendations-list">
              {recommendations.map((rec, idx) => (
                <div key={idx} className={`recommendation-card ${rec.action.toLowerCase()}`}>
                  <div className="rec-currency">{rec.currency}</div>
                  <div className="rec-action">{rec.action}</div>
                  <div className="rec-confidence">
                    Confidence: {rec.confidence}%
                  </div>
                  <div className="rec-change">
                    Predicted: {rec.predicted_change}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No strong recommendations at the moment</p>
          )}
        </section>

        {/* Risk Management Calculator */}
        <section className="risk-manager">
          <h2>⚠️ Risk Management Calculator</h2>
          <div className="risk-inputs">
            <div className="input-group">
              <label>Account Balance ($)</label>
              <input 
                type="number" 
                value={riskParams.account_balance}
                onChange={(e) => handleRiskParamChange('account_balance', e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Risk per Trade (%)</label>
              <input 
                type="number" 
                value={riskParams.risk_percent}
                onChange={(e) => handleRiskParamChange('risk_percent', e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Entry Price</label>
              <input 
                type="number" 
                step="0.0001"
                value={riskParams.entry_price}
                onChange={(e) => handleRiskParamChange('entry_price', e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Stop Loss</label>
              <input 
                type="number" 
                step="0.0001"
                value={riskParams.stop_loss}
                onChange={(e) => handleRiskParamChange('stop_loss', e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Take Profit</label>
              <input 
                type="number" 
                step="0.0001"
                value={riskParams.take_profit}
                onChange={(e) => handleRiskParamChange('take_profit', e.target.value)}
              />
            </div>
          </div>
          <button className="calculate-btn" onClick={calculateRisk}>
            Calculate Risk Parameters
          </button>

          {riskResults && (
            <div className="risk-results">
              <div className="result-card">
                <span>Position Size</span>
                <strong>{riskResults.position_size}</strong>
              </div>
              <div className="result-card">
                <span>Risk/Reward Ratio</span>
                <strong>{riskResults.risk_reward_ratio}:1</strong>
              </div>
              <div className="result-card">
                <span>Max Loss</span>
                <strong>${riskResults.max_loss?.toFixed(2)}</strong>
              </div>
              <div className="result-card">
                <span>Potential Profit</span>
                <strong>${riskResults.potential_profit?.toFixed(2)}</strong>
              </div>
            </div>
          )}
        </section>

        {/* Detailed Currency View */}
        {selectedCurrency && predictions[selectedCurrency] && (
          <section className="currency-detail">
            <h2>📈 {selectedCurrency} Analysis</h2>
            <div className="detail-grid">
              <div className="detail-card">
                <span>Current Price</span>
                <strong>{prices[selectedCurrency]?.current_price?.toFixed(4)}</strong>
              </div>
              <div className="detail-card">
                <span>Prediction</span>
                <strong>{predictions[selectedCurrency].direction.toUpperCase()}</strong>
              </div>
              <div className="detail-card">
                <span>Confidence</span>
                <strong>{(predictions[selectedCurrency].confidence * 100).toFixed(2)}%</strong>
              </div>
              <div className="detail-card">
                <span>Volatility</span>
                <strong>{predictions[selectedCurrency].volatility?.toFixed(6)}</strong>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

export default App;
